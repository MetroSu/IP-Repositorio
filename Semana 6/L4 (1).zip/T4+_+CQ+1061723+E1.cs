﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4___CQ_1061723_E1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese los valores");
            Console.WriteLine("Velocidad final");
            int VF = 0; VF = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Velocidad inicial");
            int VO = 0; VO = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Tiempo");
            int T = 0; T = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Velocidad");
            int A = 0; A = Convert.ToInt32(Console.ReadLine());

            if (VF == 0 && VO == 0 && A == 0 && T == 0)
            {
                Console.WriteLine("Datos erroneos");
            }
            else if (VO == 0)
            {
                VO = (VF / T) - A;
                Console.WriteLine("La velocidad inicial sera de " + VO + "m/s");
            }
            else if (VF == 0)
            {
                VF = VO + A * T;
                Console.WriteLine("La velocidad final sera de " + VF + "m/s");
            }
            else if (T == 0)
            {
                T = (VF - VO) / A;
                Console.WriteLine("El tiempo sera de " + T + "s");
            }
            else if (A == 0)
            {
                A = (VF - VO) / T;
                Console.WriteLine("La aceleracion sera de " + A + "m/s^2");
            }
            else
            {
                Console.WriteLine("Llenado erroneo");
            }

            Console.ReadKey();
        }
    }
}

