﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5___CQ_1061723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingrese un numero ENTERO");
            double o; o= Convert.ToDouble(Console.ReadLine());

            if (o > 0)
            {
                Console.WriteLine("NUMERO POSITIVO");
            }
            if (o < 0)
            {
                Console.WriteLine("NUMERO NEGATIVO");
            }
            if (o == 0)
            {
                Console.WriteLine("CERO");
            }
        Console.ReadKey();
         }
    }
}
