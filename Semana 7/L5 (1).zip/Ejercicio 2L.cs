﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5___CQ_1061723_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingrese el numero de día");
            int o; o = Convert.ToInt32(Console.ReadLine());

            if(o > 7 || o < 0 || o == 0)
            {
                Console.WriteLine("El numero a ingresar debe de estar contenido entre 1 y 7");
            }
            if (o == 1)
            {
                Console.WriteLine("Lunes");
            }
            if(o == 2)
            {
                Console.WriteLine("Martes");
            }
            if(o == 3)
            {
                Console.WriteLine("Miercoles");
            }
            if(o == 4)
            {
                Console.WriteLine("Jueves");
            }
            if(o == 5)
            {
                Console.WriteLine("Viernes");
            }
            if(o == 6)
            {
                Console.WriteLine("Sabado");
            }
            if(o == 7)
            {
                Console.WriteLine("Domingo");
            }
            Console.ReadKey();   
        }
    }
}
