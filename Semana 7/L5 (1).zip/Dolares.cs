﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dolares
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la primera cantidad");
            double a; a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Unidad");
            string a1; a1 = Console.ReadLine();
            Console.WriteLine("Ingrese la segunda cantidad");
            double b; b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Unidad");
            string b1; b1 = Console.ReadLine();
            Console.WriteLine("Ingrese la tercera cantidad");
            double c; c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Unidad");
            string c1; c1 = Console.ReadLine();

            if (a1 == "USD")
            {
                a = (a * 7.83);
            }
            if (b1 == "USD")
            {
                b = (b * 7.83);
            }
            if (c1 == "USD")
            {
                c = (c * 7.83);
            }
            Console.WriteLine("Resultado");
            Console.WriteLine(a + "GTQ");
            Console.WriteLine(b + "GTQ");
            Console.WriteLine(c + "GTQ");

            Console.ReadKey();
        }
    }
}
