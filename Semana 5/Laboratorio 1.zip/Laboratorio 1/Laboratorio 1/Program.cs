﻿// See https://aka.ms/new-console-template for more information
{
    Console.WriteLine("Ingrese su nombre");
    string Nombre = Console.ReadLine();

    Console.WriteLine("Hola Mundo");
    Console.WriteLine("soy" + Nombre);

    /* "WriteLine" escribe el texto, pero da un salto de pagina. Por otra parte "Write" escribe todo en una misma linea. */

    Console.Write("Hola Mundo ");
    Console.Write("Soy" + Nombre);
}
