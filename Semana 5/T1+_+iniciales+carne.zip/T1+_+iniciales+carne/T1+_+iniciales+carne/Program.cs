﻿// See https://aka.ms/new-console-template for more information
using System;
{
    Console.WriteLine("Mi Segundo Programa");

    Console.WriteLine("Nombre");
    string sNombre = Console.ReadLine();

    Console.WriteLine("Edad");
    string sEdad = Console.ReadLine();
    
    Console.WriteLine("Carrera");
    string sCarrera = Console.ReadLine();

    Console.WriteLine("Carne");
    string sCarne = Console.ReadLine();

    Console.Write("Soy " + sNombre);
    Console.Write(", tengo " + sEdad);
    Console.Write(" años y estudio la carrera de " + sCarrera);
    Console.Write(". Mi numero de carne es: " + sCarne);
}





