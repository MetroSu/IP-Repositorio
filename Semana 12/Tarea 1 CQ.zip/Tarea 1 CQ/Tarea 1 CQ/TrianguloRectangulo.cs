﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_1_CQ
{
    internal class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;
        public double ObtenerCatetoA;
        public double ObtenerCatetoB;
        public double ObtenerHipotenusa;
        public double ObtenerAnguloOpuestoA;
        public double ObtenerAnguloOpuestoB;
        public double ObtenerArea;

        public TrianguloRectangulo() 
        { 
            this.catetoA = 0.0;
            this.anguloOpuestoA = 0.0;
            this.ObtenerCatetoA = 0.0;
            this.ObtenerCatetoB = 0.0;
            this.ObtenerHipotenusa = 0.0;
            this.ObtenerAnguloOpuestoA = 0.0;
            this.ObtenerAnguloOpuestoB = 0.0;
            this.ObtenerArea = 0.0;
        }

        public TrianguloRectangulo(double catetoA, double anguloOpuestoA, double ObtenerCatetoA, double ObtenerCatetoB, double ObtenerHipotenusa, double ObtenerAnguloOpuestoA, double ObtenerAnguloOpuestoB, double ObtenerArea)
        {
            this.catetoA = catetoA;
            this.anguloOpuestoA = anguloOpuestoA;
            this.ObtenerCatetoA = ObtenerCatetoA;
            this.ObtenerCatetoB = ObtenerCatetoB;
            this.ObtenerHipotenusa = ObtenerHipotenusa;
            this.ObtenerAnguloOpuestoA = ObtenerAnguloOpuestoA;
            this.ObtenerAnguloOpuestoB = ObtenerAnguloOpuestoB;
            this.ObtenerArea = ObtenerArea;
        }


    }
}
